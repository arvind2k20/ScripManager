﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace ScripManager
{
    public partial class EquityStockWatch50 : Form
    {
        public EquityStockWatch50()
        {
            InitializeComponent();
        }

        private void EquityStockWatch50_Load(object sender, EventArgs e)
        {

            //SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\MktDB.mdf;Integrated Security=True;User Instance=True");
            //SqlCommand cmd = new SqlCommand("select * from NiftyWatch50", con);
            //con.Open();
            //SqlDataAdapter sda = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable();
            //sda.Fill(dt);
            //con.Close();
            //dataGridView1.DataSource = dt;


            ImportCSV2();
        }



        //protected void ImportCSV(object sender, EventArgs e)
        //{
        //    //Upload and save the file  


        //    //Create a DataTable.  
        //    DataTable dt = new DataTable();
        //    dt.Columns.AddRange(new DataColumn[5] { new DataColumn("Id", typeof(int)),
        //    new DataColumn("Name", typeof(string)),
        //    new DataColumn("Technology", typeof(string)),
        //    new DataColumn("Company", typeof(string)),
        //    new DataColumn("Country",typeof(string)) });

        //    //Read the contents of CSV file.  
        //    string csvData = File.ReadAllText(csvPath);

        //    //Execute a loop over the rows.  
        //    foreach (string row in csvData.Split('\n'))
        //    {
        //        if (!string.IsNullOrEmpty(row))
        //        {
        //            dt.Rows.Add();
        //            int i = 0;

        //            //Execute a loop over the columns.  
        //            foreach (string cell in row.Split(','))
        //            {
        //                dt.Rows[dt.Rows.Count - 1][i] = cell;
        //                i++;
        //            }
        //        }
        //    }

        //    //Bind the DataTable.  
        //    dataGridView1.DataSource = dt;

        //}





        protected void ImportCSV2()
        {
            try
            {
                string FileName = "data_20191018.csv";
                string CSVFilePathName = @"C:\Users\admin\Documents\Visual Studio 2015\Projects\ScripManager\ScripManager\Resources\CSV_EquityStockWatch50/" + FileName;


                // your code here 
                //string CSVFilePathName = exeFile +  @"~/Resources/CSV_EquityStockWatch50/data_20191018.CSV";
                string[] Lines = File.ReadAllLines(CSVFilePathName);
                int count = 0;
                int indexPos = 0;
                int startPosition = 0;
                int endPosition = 0;
                String[] values = new String[400];
                DataRow Row;

                //Create a DataTable.  
                DataTable dt = new DataTable();
                dt.Columns.AddRange(new DataColumn[13] {
                new DataColumn("Symbol", typeof(string)),
                new DataColumn("Open", typeof(decimal)),
                new DataColumn("High", typeof(decimal)),
                new DataColumn("Low", typeof(decimal)),
                new DataColumn("LTP",typeof(decimal)),
                new DataColumn("Change", typeof(decimal)),
                new DataColumn("Change%", typeof(decimal)),
                new DataColumn("TradedVolume(lacs)", typeof(decimal)),
                new DataColumn("Traded Value(crs)",typeof(decimal)),
                new DataColumn("52WeekHigh",typeof(decimal)),
                new DataColumn("52WeekLow",typeof(decimal)),
                new DataColumn("365 Days % Change",typeof(decimal)),
                new DataColumn("30 Days % Change",typeof(decimal))
                });


                for (int i = 1; i < Lines.GetLength(0) - 1; i++)
                {
                    string datalines = Lines[i];
                    indexPos = 0;
                    
                    Row = dt.NewRow();

                    // Use ToCharArray to convert string to array.
                    char[] array = datalines.ToCharArray();

                    // Loop through array.
                    for (int x = 0; x < array.Length; x++)
                    {
                        // Get character from array.
                        char letter = array[x];

                        if (letter.ToString() == "\"" && count == 0)
                        {
                            startPosition = x;
                            count = 1;
                        }
                        else if (letter.ToString() == "\"" && count == 1)
                        {
                            endPosition = x;
                            count = 0;
                            string data = datalines.Substring(startPosition, (endPosition - startPosition));

                            values[indexPos] = data;
                            data = Regex.Replace(data, @"(\d),(\d)", "$1$2");

                            if (Regex.IsMatch(data, @"^\d+$"))
                                Row[indexPos] = Convert.ToDecimal(data);
                            else
                                Row[indexPos] = data;

                            indexPos++;
                        }
                    } //for x

                    dt.Rows.Add(Row);

                } //for i
                
                

                
                //for (int i = 1; i < Lines.GetLength(0)-1; i++)
                //{
                //    Fields = Lines[i].Split(new char[] { ',' });
                //    Row = dt.NewRow();
                //    for (int f = 0; f < Cols; f++)
                //        Row[f] = Fields[f];
                //    dt.Rows.Add(Row);
                //}

                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error is " + ex.ToString());
                throw;
            }



        }
    }




}


   