﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScripManager.BO
{
   public enum SectoralIndex
    {
        NIFTYBANK,
        NIFTYAUTO,
        NIFTYFINSERVICE,
        NIFTYFMCG,
        NIFTYIT,
        NIFTYMEDIA,
        NIFTYMETAL,
        NIFTYPHARMA,
        NIFTYPSUBANK,
        NIFTYPVTBANK,
        NIFTYREALTY
    }

    public class Scrip
    {
        //private int _id;
        //private string _symbol;

        //public int ID 
        //{ 
        //    get
        //    { return _id; 
        //    }
        //    set
        //    {
        //        ID = _id;
        //     }
        //}

        public int ID { get; set; }
        public string Symbol { get; set; }
        public string CompanyName { get; set; }
        public decimal LTP { get; set; }

       

        public decimal FiftyTwoWeekLow { get; set; }
        public decimal FiftyTwoWeekHigh { get; set; }
        public decimal ThirtyDaysChangePercent { get; set; }
        public decimal ThreeSixtyFiveDaysChangePercent { get; set; }

        public decimal PE { get; set; }

        public decimal VWAP { get; set; }
     
        public decimal Security_VaR { get; set; }

        public Boolean DerivativeStock { get; set; }

        public decimal FaceValue { get; set; }
        public SectoralIndex SectoralIndex { get; set; }
    }


    public class NiftyStockWatch50
    {
       
        public int ID { get; set; }
        public string Symbol { get; set; }
        public string CompanyName { get; set; }
        public decimal LTP { get; set; }

        public decimal Open { get; set; }
        public decimal High { get; set; }
        public decimal Low { get; set; }
        public decimal PrevClose { get; set; }

        public decimal VolumeInLacs { get; set; }
        public decimal TodayChange { get; set; }
        public decimal TodayChagnePercent { get; set; }


        public decimal FiftyTwoWeekLow { get; set; }
        public decimal FiftyTwoWeekHigh { get; set; }
        public decimal ThirtyDaysChangePercent { get; set; }
        public decimal ThreeSixtyFiveDaysChangePercent { get; set; }

        public decimal PE { get; set; }

        public decimal VWAP { get; set; }

        public decimal LowerPriceBand { get; set; }
        public decimal UpperPriceBand { get; set; }
        public decimal PercentDeliveryQty { get; set; }

        public decimal Security_VaR { get; set; }

        public Boolean DerivativeStock { get; set; }

        public decimal FaceValue { get; set; }
        public SectoralIndex SectoralIndex { get; set; }
    }
}
